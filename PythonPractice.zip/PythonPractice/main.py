from Functions.weatherDataReq import show__weatherData
from tabulate import tabulate as tb
from colorama import Fore, Style, init
import pyttsx3 as ptx3
import time
import json

init(autoreset=True)

try:
    filePath = 'JsonData/airports.json'
    with open(filePath, 'r') as f:
         airports__json = json.load(f)
except:
    print(f" [!] Couln't Load {filePath} Check File Path...")    

def speak(text):
    engine = ptx3.init()  
    engine.say(text)
    engine.runAndWait()
    engine.stop()         

title_data = [["FENIX AIRGUIDE SIMULATION"]]
print(f"\n" + tb(title_data, tablefmt="heavy_grid", stralign="center"))

while True:
    print(" \n 1️⃣  Request Destination Data  \n 2️⃣  Weather Infromation  \n 3️⃣  Emergency Situation  \n 4️⃣  Exit")
    user__selection = input("\n 💠 Enter ( Numbers Only! ) : ") 
    
    while user__selection == "" or not user__selection.isdigit():
        user__selection = input(" Invalid Input! Enter ( Numbers Only! ) :")

    user__selection = int(user__selection)
    if user__selection == 1:
        icao__selection = input(" 💠 Enter Icao : ").upper().strip()
        if icao__selection not in airports__json:
            print(Fore.RED + " [!] Aiport Not Found...")
        else:
            details = airports__json[icao__selection]
            location = f"{details["country"]} / {details["city"]}"
            airport__data = [
            ["Name : ", details["name"]],
            ["State : ", details["state"]],
            ["TimeZone : ", details["tz"]],
            ["Location : ", location],
            ["Elevation : ", details["elevation"]]
            ]
            print()
            print(tb(airport__data, headers=["Features","Status"], tablefmt="fancy_grid"))
    
    elif user__selection == 2:
       show__weatherData()
    
    elif user__selection == 3:
          print("hello")
   
    elif user__selection == 4:
         print("\n 💠 Thanks For Using Fenix... See You Again")
         print("\n 💠 Exiting")
         speak(" Thanks For Using Fenix... See You Again")
         break
    else:
        print(Fore.RED + " [!] You Have Entered Invalid Value....")