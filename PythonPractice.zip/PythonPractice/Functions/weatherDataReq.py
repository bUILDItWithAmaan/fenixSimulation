from tabulate import tabulate as tb
from colorama import Fore, Style, init
import requests
import json

try:
    filePath = 'JsonData/airports.json'
    with open(filePath, 'r') as f:
         airports__json = json.load(f)
except:
    print(f" [!] Couln't Load {filePath} Check File Path...") 

init(autoreset=True)

def show__weatherData():
    icao =  input(" 💠 Airport ICAO ").upper().strip()
    while icao == "" or icao not in airports__json:
            icao = input(" Invalid! Enter Appoparite Icao : ")
          
    airport__details = airports__json[icao]
    airport__city = airport__details["city"]
    
    print(f"\n Fetching Weather For {icao} / {airport__city} Wait...")
    
    try: 
        url = f"https://wttr.in/{airport__city}?format=j1"
        response = requests.get(url, timeout = 10)
        data = response.json()
        current = data['current_condition'][0]
        wind__speedKmph = float(current['windspeedKmph'])
        wind__speedKts = round(wind__speedKmph/1.852, 2)
        wind__direction = current['winddir16Point']
        winddir_degree = current['winddirDegree']
        wind__arrow = "↑"
        print(winddir_degree, wind__direction)
        weather__data = [
            ["City", icao.title()],
            ["Condition", current['weatherDesc'][0]['value']],
            ["Temperature", f"{current['temp_C']}°C"],
            ["Wind Speed", f"{wind__speedKts} Kts"],
            ["Wind Direction", f"{wind__direction} ({winddir_degree}°) {wind__arrow}"],
            ["Humidity", f"{current['humidity']}%"],
            ["Pressure", f"{current['pressure']} hPa"]
        ]
        print("\n" + tb(weather__data, headers=["Features", "Status"], tablefmt="fancy_grid"))
    except Exception as e:
        print(f" [!] An Error Occured Error : {e}")

if __name__ == "__main__":
    show__weatherData()